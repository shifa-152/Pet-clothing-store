<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_name = $_POST['customer_name'] ?? 'Unknown';
    $cart_items = json_decode($_POST['cart_items'], true);
    $final_total = $_POST['final_total'];
    $coupon_code = $_POST['coupon_code'] ?? '';
    $discount = $_SESSION['discount'] ?? 0;

    // Insert order
    $stmt = $conn->prepare("INSERT INTO orders (customer_name, total, coupon_code, discount) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sdss", $customer_name, $final_total, $coupon_code, $discount);
    $stmt->execute();
    $order_id = $stmt->insert_id;

    // Insert order items
    $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, product_name, price, quantity) VALUES (?, ?, ?, ?, ?)");
    foreach ($cart_items as $item) {
        $id = $item['id'];
        $name = $item['name'];
        $price = $item['price'];
        $quantity = $item['quantity'];
        $item_stmt->bind_param("iisdi", $order_id, $id, $name, $price, $quantity);
        $item_stmt->execute();
    }

    // Clear cart and discounts
    unset($_SESSION['cart']);
    unset($_SESSION['discount']);
    unset($_SESSION['coupon']);

    // Redirect to success page
    header("Location: order_success.php?order_id=" . $order_id);
    exit();
} else {
    echo "Invalid request!";
}
?>
