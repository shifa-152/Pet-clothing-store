<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "sql311.infinityfree.com";
$username = "if0_38978384";
$password = "eA6E8WXrk8BZsA";
$database = "if0_38978384_pet_clothing";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
