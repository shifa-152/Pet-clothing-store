<?php
include 'db.php';

$showToast = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = floatval($_POST['price']);
    $image = $_POST['image'];

    $stmt = $conn->prepare("INSERT INTO Products (name, price, image_url) VALUES (?, ?, ?)");
    $stmt->bind_param("sds", $name, $price, $image);

    if ($stmt->execute()) {
        $showToast = true;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Product</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 30px;
      background-color: #f9f9f9;
    }
    form {
      max-width: 400px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 8px rgba(0,0,0,0.1);
    }
    input[type="text"], input[type="number"] {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    button {
      background-color: #27ae60;
      color: white;
      border: none;
      padding: 12px;
      width: 100%;
      border-radius: 5px;
      cursor: pointer;
    }
    button:hover {
      background-color: #219150;
    }

    /* Toast styling */
    .toast {
      visibility: hidden;
      min-width: 250px;
      background-color: #2ecc71;
      color: white;
      text-align: center;
      border-radius: 6px;
      padding: 16px;
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 1000;
      box-shadow: 0 0 10px rgba(0,0,0,0.3);
      opacity: 0;
      transition: visibility 0s, opacity 0.5s ease-in-out;
    }

    .toast.show {
      visibility: visible;
      opacity: 1;
    }
  </style>
</head>
<body>

<form method="POST">
  <h2>Add Product</h2>
  <input type="text" name="name" placeholder="Product Name" required>
  <input type="number" name="price" placeholder="Price (₹)" step="0.01" required>
  <input type="text" name="image" placeholder="Image URL" required>
  <button type="submit">Add Product</button>
</form>

<div id="toast" class="toast">✅ Product added successfully!</div>

<?php if ($showToast): ?>
  <script>
    window.onload = function() {
      const toast = document.getElementById("toast");
      toast.classList.add("show");
      setTimeout(() => toast.classList.remove("show"), 3000);
    }
  </script>
<?php endif; ?>

</body>
</html>
