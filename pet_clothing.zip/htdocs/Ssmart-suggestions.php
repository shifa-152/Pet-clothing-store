<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Smart Suggestions - PetStyle Hub</title>

  <!-- Tailwind CSS -->
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />

  <!-- AOS Animation CSS -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <style>
    body { font-family: 'Inter', sans-serif; }
  </style>
</head>
<body class="bg-gray-50 text-gray-800">

  <!-- AOS Script -->
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 1000, once: true });
  </script>

  <!-- Navbar -->
    <header class="bg-indigo-600 text-white shadow">
      <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-xl font-semibold">PetStyle Hub</h1>
        <nav class="space-x-4">
          <a href="index.php" class="hover:underline">Home</a>
          <a href="Sproducts.php" class="hover:underline">Products</a>
 	  <a href="Ssuggestions.php" class="mx-2 hover:underline">AI Suggestions</a>
          <a href="Ssmart-suggestions.php" class="hover:underline">Smart Suggestion</a>
          <a href="Stryon.php" class="hover:underline">AR Try-on</a>
          <a href="Scart.php" class="hover:underline">Cart🛒</a>
<button onclick="logout()" class="ml-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">Logout</button>
        </nav>
      </div>
    </header>
<script>
  function logout() {
    localStorage.removeItem("loggedIn");
    alert("You have been logged out.");
    window.location.href = "Slogin.php";
  }
</script>
  <!-- Main Content -->
  <main class="max-w-4xl mx-auto p-6">
    <h2 class="text-3xl font-bold text-indigo-600 text-center mb-6" data-aos="fade-down">Smart Suggestions for Your Pet</h2>

    <div class="bg-white rounded-xl shadow-lg p-6" data-aos="fade-up">
      <p class="mb-4 text-gray-600 text-center">Upload a picture of your pet and enter their details to receive customized style and product suggestions!</p>
      
      <form id="smartSuggestionForm" class="space-y-6" enctype="multipart/form-data">
        <div>
          <label for="petName" class="block text-sm font-semibold text-gray-700">Pet's Name</label>
          <input type="text" id="petName" name="petName" class="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500" required>
        </div>

        <div>
          <label for="petDetails" class="block text-sm font-semibold text-gray-700">Pet Description</label>
          <textarea id="petDetails" name="petDetails" rows="4" class="mt-1 w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500" placeholder="Breed, size, preferences, age, etc." required></textarea>
        </div>

        <div>
          <label for="petImage" class="block text-sm font-semibold text-gray-700">Upload Image</label>
          <input type="file" id="petImage" name="petImage" accept="image/*" class="mt-1 w-full" required />
        </div>

        <button type="submit" class="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition">Get Suggestions</button>
      </form>

      <div id="suggestionResult" class="mt-6 hidden p-4 border border-green-300 bg-green-50 text-green-700 rounded-lg">
        <!-- Suggestions will appear here -->
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-indigo-600 text-white mt-10">
    <div class="max-w-7xl mx-auto px-4 py-6 text-center">
      <p>&copy; 2025 PetStyle Hub. All rights reserved.</p>
<p class="mt-2 text-sm">Made with <span class="text-red-500">❤️</span> by Shifa Pawaskar</p>
    </div>
  </footer>

  <!-- JS -->
  <script>
    const form = document.getElementById('smartSuggestionForm');
    const resultBox = document.getElementById('suggestionResult');

    form.addEventListener('submit', function(e) {
      e.preventDefault();
      resultBox.innerHTML = '<strong>Thank you!</strong> We are processing your pet’s details and will show suggestions shortly.';
      resultBox.classList.remove('hidden');
    });
  </script>
</body>
</html>
