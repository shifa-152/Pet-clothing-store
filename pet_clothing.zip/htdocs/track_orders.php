<?php
include 'db.php';

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
$order = null;

if ($order_id > 0) {
    $stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $order = $result->fetch_assoc();
    }
}

$statuses = [
  "Order Placed",
  "Packed",
  "Shipped",
  "Out for Delivery",
  "Delivered"
];
?>

<!DOCTYPE html>
<html>
<head>
  <title>Track Order <?= $order ? "#$order_id" : "" ?></title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f2f2f2;
      margin: 0;
    }
    .container {
      max-width: 700px;
      margin: 50px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      position: relative;
    }
    h2 {
      text-align: center;
      color: #2c3e50;
    }
    .tracker {
      display: flex;
      justify-content: space-between;
      margin: 40px 0;
      position: relative;
    }
    .tracker::before {
      content: "";
      position: absolute;
      top: 50%;
      left: 0;
      height: 4px;
      width: 100%;
      background: #ccc;
      z-index: 0;
      transform: translateY(-50%);
    }
    .step {
      position: relative;
      z-index: 1;
      text-align: center;
      flex: 1;
    }
    .step .circle {
      height: 30px;
      width: 30px;
      background: #ccc;
      border-radius: 50%;
      margin: 0 auto 10px;
      line-height: 30px;
      color: white;
      font-weight: bold;
    }
    .step.active .circle {
      background: #27ae60;
    }
    .step span {
      font-size: 14px;
      color: #444;
    }
    .back-btn {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 16px;
      background: #3498db;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }
    .footer {
      text-align: center;
      color: #888;
      margin-top: 30px;
    }
    .error-msg {
      text-align: center;
      color: red;
      font-size: 18px;
    }
  </style>
</head>
<body>
  <div class="container">
    <?php if ($order): ?>
      <h2>Track Your Order</h2>
      <p><strong>Customer:</strong> <?= htmlspecialchars($order['customer_name']) ?></p>
      <p><strong>Status:</strong> <?= htmlspecialchars($order['status']) ?></p>

      <div class="tracker">
        <?php
        $currentStatus = $order['status'];
        $reached = true;

        foreach ($statuses as $step):
          $isActive = $reached ? "active" : "";
        ?>
          <div class="step <?= $isActive ?>">
            <div class="circle"><?= $isActive ? "✓" : "" ?></div>
            <span><?= $step ?></span>
          </div>
        <?php
          if ($step === $currentStatus) $reached = false;
        endforeach;
        ?>
      </div>
    <?php else: ?>
      <p class="error-msg">⚠️  Order Not Found.</p>
    <?php endif; ?>

    <a href="index.php" class="back-btn">🏠 Back to Home</a>
  </div>

  <div class="footer">
    © 2025 PetStyle Hub. Made with ❤️ by Shifa Pawaskar
  </div>
</body>
</html>
