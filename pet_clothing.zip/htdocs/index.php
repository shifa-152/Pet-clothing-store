<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sindex</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
    <!-- AOS Animation CSS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <style>
      body { font-family: 'Inter', sans-serif; }
    </style>
  </head>
  <body class="bg-gray-50 text-gray-800">
    <!-- AOS Script -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init({
        duration: 1000,
        once: true
      });
    </script>

    <!-- Navbar -->
    <header class="bg-indigo-600 text-white shadow">
      <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-xl font-semibold">PetStyle Hub</h1>
        <nav class="space-x-4">
          <a href="index.php" class="hover:underline">Home</a>
          <a href="Sproducts.php" class="hover:underline">Products</a>
 	  <a href="Ssuggestions.php" class="mx-2 hover:underline">AI Suggestions</a>
          <a href="Ssmart-suggestions.php" class="hover:underline">Smart Suggestion</a>
          <a href="Stryon.php" class="hover:underline">AR Try-on</a>
          <a href="Scart.php" class="hover:underline">Cart🛒</a>
<button onclick="logout()" class="ml-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">Logout</button>
        </nav>
      </div>
    </header>
<script>
  function logout() {
    localStorage.removeItem("loggedIn");
    alert("You have been logged out.");
    window.location.href = "Slogin.php";
  }
</script>


    <!-- Main Content -->
    <main class="max-w-6xl mx-auto p-6">
      <h1 class="text-4xl font-bold text-pink-600 mb-6">Welcome to PetStyle Hub</h1>
      <div class="space-x-4">
        <a href="Slogin.php" class="bg-pink-500 text-white px-6 py-2 rounded hover:bg-pink-600">Login</a>
        <a href="Ssignup.php" class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600">Sign Up</a>
      </div>

      <div class="text-center mt-6">
        <a href="Sadmin_login.php" class="inline-block px-6 py-3 bg-purple-600 text-white rounded-lg shadow hover:bg-purple-700 transition">
          Admin Login
        </a>
      </div>

      <!-- Cat Image Section -->
      <section class="my-10">
        <h2 class="text-2xl font-semibold text-center text-indigo-700 mb-6" data-aos="fade-up">Adorable Cat Styles</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          <img src="https://m.media-amazon.com/images/I/61sGkBtx+eL._AC_UF1000,1000_QL80_.jpg"
               class="rounded-xl shadow-md transition-transform duration-500 transform hover:rotate-3 hover:scale-105 hover:shadow-2xl"
               data-aos="slide-up">
          <img src="https://cdn.shopify.com/s/files/1/0568/0450/7691/files/pet_costumes_1_480x480.jpg?v=1688134274"
               class="rounded-xl shadow-md transition-transform duration-500 transform hover:rotate-3 hover:scale-105 hover:shadow-2xl"
               data-aos="slide-up" data-aos-delay="100">
          <img src="https://ak1.ostkcdn.com/images/products/23150554/High-Grade-Fashion-Halloween-Cat-Dog-Clothes-Funny-Outfit-Pet-Dog-60265bff-52e9-4c93-bfd4-ab1cfc0f9cb1_600.jpg?impolicy=medium"
               class="rounded-xl shadow-md transition-transform duration-500 transform hover:rotate-3 hover:scale-105 hover:shadow-2xl"
               data-aos="slide-up" data-aos-delay="200">
          <img src="https://i.pinimg.com/236x/b5/b4/70/b5b470ba47260a25fca62a4308f7a934.jpg" alt="Cute Cat 4"
               class="rounded-xl shadow-md transition-transform duration-500 transform hover:rotate-3 hover:scale-105 hover:shadow-2xl"
               data-aos="slide-up" data-aos-delay="300">
          <img src="https://i.pinimg.com/236x/4f/52/c8/4f52c8686026a78b2c9bb2307f76bd8a.jpg" alt="Cute Cat 5"
               class="rounded-xl shadow-md transition-transform duration-500 transform hover:rotate-3 hover:scale-105 hover:shadow-2xl"
               data-aos="slide-up" data-aos-delay="400">
          <img src="https://i.pinimg.com/736x/94/5f/50/945f50c4bce4f6223d7f10f41e036336.jpg" alt="Cute Cat 6"
               class="rounded-xl shadow-md transition-transform duration-500 transform hover:rotate-3 hover:scale-105 hover:shadow-2xl"
               data-aos="slide-up" data-aos-delay="500">
        </div>
      </section>
    </main>

    <!-- Footer -->
    <footer class="bg-indigo-600 text-white mt-10">
      <div class="max-w-7xl mx-auto px-4 py-6 text-center">
        <p>&copy; 2025 PetStyle Hub. All rights reserved.</p>
<p class="mt-2 text-sm">Made with <span class="text-red-500">❤️</span> by Shifa Pawaskar</p>
      </div>
    </footer>
  </body>
</html>
