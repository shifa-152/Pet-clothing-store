<?php
include 'db.php';

$data = json_decode(file_get_contents('php://input'), true);
$response = [];

foreach ($data as $item) {
    $product_id = intval($item['id']);
    $quantity = intval($item['quantity']);

    $stmt = $conn->prepare("SELECT id, name, price, image_url FROM Products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product) {
        $product['quantity'] = $quantity;
        $response[] = $product;
    }

    $stmt->close();
}
header('Content-Type: application/json');
echo json_encode($response);
?>
<?php
include 'db.php';

$data = json_decode(file_get_contents('php://input'), true);
$response = [];

foreach ($data as $item) {
    $product_id = intval($item['id']);
    $quantity = intval($item['quantity']);

    $stmt = $conn->prepare("SELECT id, name, price, image_url FROM Products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product) {
        $product['quantity'] = $quantity;
        $response[] = $product;
    }

    $stmt->close();
}
header('Content-Type: application/json');
echo json_encode($response);
?>
