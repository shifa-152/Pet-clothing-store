<?php
session_start();
include 'db.php';

$cart = $_SESSION['cart'] ?? [];

// Simple sample coupons (You can fetch from DB if needed)
$coupons = [
    "PET10" => 10,      // 10% off
    "SAVE100" => 100,   // ₹100 flat off
];

$total = 0;
foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Handle coupon
$discount = 0;
$couponCode = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['apply_coupon'])) {
    $couponCode = strtoupper(trim($_POST['coupon']));
    if (isset($coupons[$couponCode])) {
        $discountValue = $coupons[$couponCode];
        $discount = ($discountValue < 100) ? ($total * ($discountValue / 100)) : $discountValue;
        $_SESSION['discount'] = $discount;
        $_SESSION['coupon'] = $couponCode;
    } else {
        $error = "Invalid coupon code.";
    }
}

// Apply previously applied discount if exists
if (isset($_SESSION['discount'])) {
    $discount = $_SESSION['discount'];
    $couponCode = $_SESSION['coupon'];
}

$grandTotal = $total - $discount;
?>

<!DOCTYPE html>
<html>
<head>
  <title>Your Cart - PetStyle Hub</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif; margin: 0; background: #f6f6f6;
    }
    .container {
      max-width: 800px; margin: 40px auto; background: #fff;
      padding: 20px; border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h1 { text-align: center; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    table th, table td { padding: 12px; border-bottom: 1px solid #ddd; text-align: center; }
    table img { width: 60px; border-radius: 6px; }
    .qty-btn {
      padding: 4px 10px; font-size: 16px;
      border: none; background: #ddd; border-radius: 4px;
      cursor: pointer;
    }
    .delete-btn {
      background: #e74c3c; color: white; padding: 6px 10px;
      border: none; border-radius: 4px; cursor: pointer;
    }
    .summary {
      text-align: right; font-size: 18px;
    }
    .summary div { margin: 5px 0; }
    input[type="text"] {
      width: 100%; padding: 10px; margin-top: 10px;
      border: 1px solid #ccc; border-radius: 5px;
    }
    .coupon-form {
      display: flex; gap: 10px; margin-top: 15px;
    }
    .coupon-form input[type="text"] {
      flex: 1;
    }
    .coupon-form button {
      padding: 10px 15px; background: #3498db; color: #fff;
      border: none; border-radius: 5px; cursor: pointer;
    }
    .place-order {
      width: 100%; padding: 12px; margin-top: 20px;
      background: #2ecc71; color: white;
      font-size: 18px; border: none; border-radius: 6px;
      cursor: pointer;
    }
    .footer {
      text-align: center; margin-top: 30px; color: #777;
    }
    .error { color: red; }
  </style>
  <script>
    function updateQuantity(id, change) {
      fetch('update_cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id, change: change })
      }).then(() => window.location.reload());
    }

    function removeItem(id) {
      fetch('remove_from_cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
      }).then(() => window.location.reload());
    }
  </script>
</head>
<body>
  <div class="container">
    <h1>Your Cart</h1>
    <a href="Sproducts.php">← Back to Shop</a>

    <?php if (count($cart) > 0): ?>
    <table>
      <tr>
        <th>Image</th><th>Product</th><th>Price</th><th>Qty</th><th>Remove</th>
      </tr>
      <?php foreach ($cart as $item): ?>
      <tr>
        <td><img src="<?= htmlspecialchars($item['image']) ?>"></td>
        <td><?= htmlspecialchars($item['name']) ?></td>
        <td>₹<?= number_format($item['price']) ?></td>
        <td>
          <button class="qty-btn" onclick="updateQuantity(<?= $item['id'] ?>, -1)">−</button>
          <?= $item['quantity'] ?>
          <button class="qty-btn" onclick="updateQuantity(<?= $item['id'] ?>, 1)">+</button>
        </td>
        <td><button class="delete-btn" onclick="removeItem(<?= $item['id'] ?>)">Delete</button></td>
      </tr>
      <?php endforeach; ?>
    </table>

    <form method="POST">
      <div class="coupon-form">
        <input type="text" name="coupon" placeholder="Enter Coupon Code" value="<?= htmlspecialchars($couponCode) ?>">
        <button name="apply_coupon" type="submit">Apply</button>
      </div>
      <?php if (!empty($error)): ?>
        <p class="error"><?= $error ?></p>
      <?php endif; ?>
    </form>

    <div class="summary">
      <div><strong>Subtotal:</strong> ₹<?= number_format($total) ?></div>
      <div><strong>Discount:</strong> -₹<?= number_format($discount) ?></div>
      <div><strong>Total:</strong> ₹<?= number_format($grandTotal) ?></div>
    </div>

    <form method="POST" action="place_order.php">
      <label>Customer Name</label>
      <input type="text" name="customer_name" required>

      <input type="hidden" name="cart_items" value='<?= json_encode($cart) ?>'>
      <input type="hidden" name="final_total" value="<?= $grandTotal ?>">
      <input type="hidden" name="coupon_code" value="<?= $couponCode ?>">

      <button class="place-order" type="submit">Place Order</button>
    </form>

    <?php else: ?>
      <p style="text-align:center;">Your cart is empty.</p>
    <?php endif; ?>
  </div>

  <div class="footer">
    © 2025 PetStyle Hub. Made with ❤️ by Shifa Pawaskar
  </div>
</body>
</html>
