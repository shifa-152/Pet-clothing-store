<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: Sadmin_login.php");
    exit();
}

include '../db.php';

if (isset($_GET['id'])) {
    $order_id = $_GET['id'];

    // Update the order status
    $sql = "UPDATE orders SET status='Shipped' WHERE id='$order_id'";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Order status updated to Shipped.'); window.location.href = 'track_orders.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }

    $conn->close();
}
?>
	