<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM Products WHERE id='$id'";
    $result = $conn->query($sql);
    $product = $result->fetch_assoc();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];

        $update_sql = "UPDATE products SET name='$name', description='$description', price='$price' WHERE id='$id'";
        if ($conn->query($update_sql) === TRUE) {
            header("Location: index.php");
            exit();
        } else {
            echo "Error: " . $update_sql . "<br>" . $conn->error;
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <header>
        <img src="../assets/images/logo.png" alt="Pet Clothing Logo" class="logo">
        <nav>
            <a href="index.php">Dashboard</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </header>

    <main>
        <h2>Edit Product</h2>
        <form method="POST" action="">
            <label>Product Name:</label><br>
            <input type="text" name="name" value="<?php echo $product['name']; ?>" required><br>
            <label>Description:</label><br>
            <textarea name="description" required><?php echo $product['description']; ?></textarea><br>
            <label>Price:</label><br>
            <input type="text" name="price" value="<?php echo $product['price']; ?>" required><br>
            <button type="submit">Update Product</button>
        </form>
    </main>

    <footer>
        <p>&copy; 2025 Pet Clothing. All rights reserved.</p>
    </footer>
</body>
</html>
