<?php
session_start();
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['id'])) {
    $_SESSION['cart'] = array_filter($_SESSION['cart'], function($item) use ($data) {
        return $item['id'] != $data['id'];
    });
    $_SESSION['cart'] = array_values($_SESSION['cart']); // re-index
}
