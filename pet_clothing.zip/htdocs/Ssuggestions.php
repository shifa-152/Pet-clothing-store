<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>AI Suggestion - PetStyle Hub</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs"></script>
  <script src="https://cdn.jsdelivr.net/npm/@tensorflow-models/mobilenet"></script>
  <style>
    body { font-family: 'Inter', sans-serif; }
  </style>
</head>
<body class="bg-gray-50 text-gray-800">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 1000, once: true });
    function logout() {
      localStorage.removeItem("loggedIn");
      alert("Logged out!");
      window.location.href = "Sindex.html";
    }
  </script>

 <!-- Navbar -->
    <header class="bg-indigo-600 text-white shadow">
      <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-xl font-semibold">PetStyle Hub</h1>
        <nav class="space-x-4">
          <a href="index.php" class="hover:underline">Home</a>
          <a href="Sproducts.php" class="hover:underline">Products</a>
 	  <a href="Ssuggestions.php" class="mx-2 hover:underline">AI Suggestions</a>
          <a href="Ssmart-suggestions.php" class="hover:underline">Smart Suggestion</a>
          <a href="Stryon.php" class="hover:underline">AR Try-on</a>
          <a href="Scart.php" class="hover:underline">Cart🛒</a>
<button onclick="logout()" class="ml-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">Logout</button>
        </nav>
      </div>
    </header>
<script>
  function logout() {
    localStorage.removeItem("loggedIn");
    alert("You have been logged out.");
    window.location.href = "Slogin.php";
  }
</script>

  <!-- Main Content -->
  <main class="max-w-4xl mx-auto p-6">
    <h2 class="text-3xl font-bold text-center text-pink-600 mb-8" data-aos="fade-down">AI-Powered Style Suggestions</h2>

    <div class="bg-white rounded-lg shadow-md p-6" data-aos="fade-up">
      <p class="mb-4 text-lg text-gray-700">Upload a photo of your pet to receive style suggestions using AI!</p>
      <input type="file" id="imageUpload" accept="image/*" class="mb-4 block w-full border border-gray-300 rounded px-4 py-2" />
      <button onclick="analyzeImage()" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700 transition">Get Suggestions</button>
    </div>

    <div id="suggestions" class="mt-6 p-4 bg-gray-100 rounded-lg shadow-sm" data-aos="fade-up" data-aos-delay="200">
      <!-- Suggestions will appear here -->
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-indigo-600 text-white mt-10">
    <div class="max-w-7xl mx-auto px-4 py-6 text-center">
      <p>&copy; 2025 PetStyle Hub. All rights reserved.</p>
<p class="mt-2 text-sm">Made with <span class="text-red-500">❤️</span> by Shifa Pawaskar</p>
    </div>
  </footer>

  <script>
    async function analyzeImage() {
      const imageUpload = document.getElementById('imageUpload');
      const suggestionsDiv = document.getElementById('suggestions');
      if (!imageUpload.files.length) {
        alert("Please upload an image first.");
        return;
      }

      const file = imageUpload.files[0];
      const img = new Image();
      img.src = URL.createObjectURL(file);
      img.onload = async () => {
        const model = await mobilenet.load();
        const predictions = await model.classify(img);
        suggestionsDiv.innerHTML = '<h3 class="text-xl font-semibold mb-2">Suggestions:</h3>' +
          predictions.map(p => `<p class="text-gray-700">🐾 ${p.className}</p>`).join('');
      };
    }
  </script>
</body>
</html>
