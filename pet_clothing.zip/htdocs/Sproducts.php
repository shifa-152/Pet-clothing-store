<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include 'db.php';
// Fetch all products
$sql = "SELECT * FROM Products";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>PetStyle Hub - Products</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-gray-800 min-h-screen flex flex-col">
  <header class="bg-indigo-600 text-white p-4 shadow">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
      <h1 class="text-2xl font-bold">PetStyle Hub - Products</h1>
      <a href="Scart.php" class="bg-white text-indigo-600 px-4 py-2 rounded hover:bg-gray-100 transition">View Cart</a>
    </div>
  </header>
  <main class="flex-grow p-6">
    <div class="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      <?php if ($result->num_rows > 0): ?>
        <?php while($product = $result->fetch_assoc()): ?>
          <div class="bg-white p-4 rounded-lg shadow hover:shadow-lg transition">
            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="Product Image" class="w-full h-50 object-cover rounded mb-2">
            <h2 class="text-lg font-bold text-indigo-700"><?php echo htmlspecialchars($product['name']); ?></h2>
            <p class="text-gray-600 mb-2"><?php echo htmlspecialchars($product['description']); ?></p>
            <p class="text-indigo-600 font-semibold mb-3">₹<?php echo number_format($product['price'], 2); ?></p>
            <button onclick="addToCart(<?php echo $product['id']; ?>)" class="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700 transition">
  Add to Cart
</button>

          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p class="text-center text-gray-500">No products found.</p>
      <?php endif; ?>
    </div>
  </main>

  <footer class="bg-indigo-600 text-white text-center py-4">
    &copy; 2025 PetStyle Hub. All rights reserved.
  </footer>

  <!-- Toast & Cart Logic -->
  <script>
  function addToCart(productId) {
    fetch("add_to_cart.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ product_id: productId })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        showToast("✅ Product added to cart!");
      } else {
        showToast("❌ " + data.message);
      }
    })
    .catch(err => {
      showToast("⚠️ Error adding to cart.");
      console.error(err);
    });
  }

  function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "fixed bottom-6 right-6 bg-green-600 text-white px-4 py-2 rounded shadow-lg animate-bounce z-50";
    toast.innerText = message;

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.transition = "opacity 0.5s ease";
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 500);
    }, 2000);
  }
</script>

</body>
</html>
