<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: Sadmin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard - PetStyle Hub</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Inter', sans-serif;
    }
  </style>
</head>
<body class="bg-gray-100 text-gray-800 min-h-screen flex flex-col">

  <!-- Header -->
  <header class="bg-indigo-600 text-white p-4 shadow">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
      <h1 class="text-2xl font-bold">Admin Dashboard</h1>
      <a href="Sadmin_login.html" class="text-sm bg-white text-indigo-600 px-4 py-2 rounded hover:bg-gray-100 transition">Logout</a>
    </div>
  </header>

  <!-- Main Content -->
  <main class="flex-grow flex items-center justify-center p-6">
    <div class="bg-white p-8 rounded-xl shadow-md w-full max-w-3xl text-center">
      <h2 class="text-3xl font-bold text-indigo-700 mb-4">Welcome Admin</h2>
      <p class="text-gray-600 mb-6">Manage users, products, and site settings from here.</p>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 text-left">
        <div class="p-4 border rounded-lg hover:shadow transition">
          <h3 class="text-lg font-semibold text-indigo-600">User Management</h3>
          <p class="text-sm text-gray-600">View, add, or remove registered users.</p>
        </div>
        <div class="p-4 border rounded-lg hover:shadow transition">
  <h3 class="text-lg font-semibold text-indigo-600">Product Listings</h3>
  <p class="text-sm text-gray-600">Manage product information and stock.</p>
  <a href="add_product.php" class="text-indigo-600 underline text-sm">Add New Product</a>
</div>

        <div class="p-4 border rounded-lg hover:shadow transition">
    <h3 class="text-lg font-semibold text-indigo-600">Orders</h3>
    <p class="text-sm text-gray-600">Track and fulfill customer orders.</p>
    <a href="track_orders.php" class="text-indigo-600 underline text-sm">Track Orders</a>
</div>

        <div class="p-4 border rounded-lg hover:shadow transition">
          <h3 class="text-lg font-semibold text-indigo-600">Reports</h3>
          <p class="text-sm text-gray-600">Analyze sales and performance data.</p>
        </div>
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-indigo-600 text-white text-center py-4">
    &copy; 2025 PetStyle Hub. All rights reserved.
<p class="mt-2 text-sm">Made with <span class="text-red-500">❤️</span> by Shifa Pawaskar</p>
  </footer>
</body>
</html>
