<?php
session_start();
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['id'], $data['change'])) {
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $data['id']) {
            $item['quantity'] += $data['change'];
            if ($item['quantity'] < 1) $item['quantity'] = 1;
            break;
        }
    }
}
