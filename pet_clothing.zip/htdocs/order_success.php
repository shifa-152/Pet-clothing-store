<?php
include 'db.php';

$order_id = $_GET['order_id'] ?? 0;

$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

$item_stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$item_stmt->bind_param("i", $order_id);
$item_stmt->execute();
$items = $item_stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Order Confirmation</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f3f3f3;
      margin: 0;
    }
    .container {
      max-width: 700px;
      margin: 50px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      position: relative;
    }
    .button-row {
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      margin-bottom: 20px;
    }
    .home-btn, .track-btn {
      padding: 10px 18px;
      background: #3498db;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      border: none;
      cursor: pointer;
      transition: background 0.3s;
    }
    .home-btn:hover, .track-btn:hover {
      background-color: #2980b9;
    }
    h2 {
      color: green;
      text-align: center;
      text-transform: capitalize;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
      text-align: center;
    }
    .total {
      text-align: right;
      margin-top: 20px;
      font-size: 18px;
    }
    .footer {
      margin-top: 40px;
      text-align: center;
      color: #777;
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Button Row -->
    <div class="button-row">
      <a href="track_orders.php?order_id=<?= $order_id ?>" class="track-btn">🚚 Track Order</a>
      <a href="index.php" class="home-btn">🏠 Home</a>
    </div>

    <h2>Thank you, <?= htmlspecialchars($order['customer_name']) ?>! 🎉</h2>
    <p>Your order has been placed successfully. </p>

    <table>
      <tr>
        <th>Product</th>
        <th>Qty</th>
        <th>Price</th>
        <th>Subtotal</th>
      </tr>
      <?php while($row = $items->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['product_name']) ?></td>
          <td><?= $row['quantity'] ?></td>
          <td>₹<?= number_format($row['price'], 2) ?></td>
          <td>₹<?= number_format($row['price'] * $row['quantity'], 2) ?></td>
        </tr>
      <?php endwhile; ?>
    </table>

    <div class="total">
      <p><strong>Total Paid: ₹<?= number_format($order['total'], 2) ?></strong></p>
      <?php if (!empty($order['coupon_code'])): ?>
        <p>Coupon Applied: <strong><?= $order['coupon_code'] ?></strong> (Saved ₹<?= number_format($order['discount'], 2) ?>)</p>
      <?php endif; ?>
    </div>

    <div class="footer">
      © 2025 PetStyle Hub. Made with ❤️ by Shifa Pawaskar
    </div>
  </div>
</body>
</html>
