<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AR Try-On - PetStyle Hub</title>

    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />

    <!-- AOS CSS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />

    <style>
      body {
        font-family: 'Inter', sans-serif;
      }
      a-scene {
        height: 80vh;
        border-radius: 1rem;
        overflow: hidden;
      }
    </style>
  </head>
  <body class="bg-gray-50 text-gray-800">

   <!-- Navbar -->
    <header class="bg-indigo-600 text-white shadow">
      <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-xl font-semibold">PetStyle Hub</h1>
        <nav class="space-x-4">
          <a href="index.php" class="hover:underline">Home</a>
          <a href="Sproducts.php" class="hover:underline">Products</a>
 	  <a href="Ssuggestions.php" class="mx-2 hover:underline">AI Suggestions</a>
          <a href="Ssmart-suggestions.php" class="hover:underline">Smart Suggestion</a>
          <a href="Stryon.php" class="hover:underline">AR Try-on</a>
          <a href="Scart.php" class="hover:underline">Cart🛒</a>
<button onclick="logout()" class="ml-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">Logout</button>
        </nav>
      </div>
    </header>
<script>
  function logout() {
    localStorage.removeItem("loggedIn");
    alert("You have been logged out.");
    window.location.href = "Slogin.php";
  }
</script>
    <!-- Main Content -->
    <main class="max-w-5xl mx-auto px-4 py-10">
      <h2 class="text-3xl font-bold text-center text-pink-600 mb-6" data-aos="fade-down">Try Styles in Augmented Reality</h2>

      <div class="bg-white p-4 shadow rounded-lg" data-aos="fade-up">
        <a-scene embedded arjs>
          <a-marker preset="hiro">
            <a-box position="0 0.5 0" material="color: pink;"></a-box>
          </a-marker>
          <a-entity camera></a-entity>
        </a-scene>
      </div>

      <p class="text-center mt-6 text-gray-600" data-aos="fade-up" data-aos-delay="300">
        Point your camera at the marker to see the virtual model in action!
      </p>
    </main>

    <!-- Footer -->
    <footer class="bg-indigo-600 text-white mt-10">
      <div class="max-w-7xl mx-auto px-4 py-6 text-center">
        <p>&copy; 2025 PetStyle Hub. All rights reserved.</p>
<p class="mt-2 text-sm">Made with <span class="text-red-500">❤️</span> by Shifa Pawaskar</p>
      </div>
    </footer>

    <!-- AOS JS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init({ duration: 1000, once: true });
    </script>

    <!-- A-Frame + AR.js -->
    <script src="https://aframe.io/releases/1.2.0/aframe.min.js"></script>
    <script src="https://raw.githack.com/AR-js-org/AR.js/master/aframe/build/aframe-ar.js"></script>
  </body>
</html>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AR Try-On - PetStyle Hub</title>

    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />

    <!-- AOS CSS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />

    <style>
      body {
        font-family: 'Inter', sans-serif;
      }
      a-scene {
        height: 80vh;
        border-radius: 1rem;
        overflow: hidden;
      }
    </style>
  </head>
  <body class="bg-gray-50 text-gray-800">

   <!-- Navbar -->
    <header class="bg-indigo-600 text-white shadow">
      <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-xl font-semibold">PetStyle Hub</h1>
        <nav class="space-x-4">
          <a href="index.php" class="hover:underline">Home</a>
          <a href="Sproducts.php" class="hover:underline">Products</a>
 	  <a href="Ssuggestions.php" class="mx-2 hover:underline">AI Suggestions</a>
          <a href="Ssmart-suggestions.php" class="hover:underline">Smart Suggestion</a>
          <a href="Stryon.php" class="hover:underline">AR Try-on</a>
          <a href="Scart.php" class="hover:underline">Cart🛒</a>
<button onclick="logout()" class="ml-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">Logout</button>
        </nav>
      </div>
    </header>
<script>
  function logout() {
    localStorage.removeItem("loggedIn");
    alert("You have been logged out.");
    window.location.href = "Slogin.php";
  }
</script>
    <!-- Main Content -->
    <main class="max-w-5xl mx-auto px-4 py-10">
      <h2 class="text-3xl font-bold text-center text-pink-600 mb-6" data-aos="fade-down">Try Styles in Augmented Reality</h2>

      <div class="bg-white p-4 shadow rounded-lg" data-aos="fade-up">
        <a-scene embedded arjs>
          <a-marker preset="hiro">
            <a-box position="0 0.5 0" material="color: pink;"></a-box>
          </a-marker>
          <a-entity camera></a-entity>
        </a-scene>
      </div>

      <p class="text-center mt-6 text-gray-600" data-aos="fade-up" data-aos-delay="300">
        Point your camera at the marker to see the virtual model in action!
      </p>
    </main>

    <!-- Footer -->
    <footer class="bg-indigo-600 text-white mt-10">
      <div class="max-w-7xl mx-auto px-4 py-6 text-center">
        <p>&copy; 2025 PetStyle Hub. All rights reserved.</p>
<p class="mt-2 text-sm">Made with <span class="text-red-500">❤️</span> by Shifa Pawaskar</p>
      </div>
    </footer>

    <!-- AOS JS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init({ duration: 1000, once: true });
    </script>

    <!-- A-Frame + AR.js -->
    <script src="https://aframe.io/releases/1.2.0/aframe.min.js"></script>
    <script src="https://raw.githack.com/AR-js-org/AR.js/master/aframe/build/aframe-ar.js"></script>
  </body>
</html>
